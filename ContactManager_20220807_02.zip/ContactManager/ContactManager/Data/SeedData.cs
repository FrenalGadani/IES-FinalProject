﻿using ContactManager.Authorization;
using ContactManager.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace ContactManager.Data
{
    public static class SeedData
    {
        public static async Task Initialize(IServiceProvider serviceProvider, string userPwd)
        {
            using (var context = new ApplicationDbContext(serviceProvider.GetRequiredService<DbContextOptions<ApplicationDbContext>>()))
            {
                // For sample purposes seed both with the same password.
                // Password is set with the following:
                // dotnet user-secrets set SeedUserPW <pw>
                // The admin user can do anything

                var adminID = await EnsureUser(serviceProvider, userPwd, "admin@contoso.com");
                await EnsureRole(serviceProvider, adminID, Constants.ContactAdminRole);

                // allowed user can create and edit contacts that they create
                var managerID = await EnsureUser(serviceProvider, userPwd, "manager@contoso.com");
                await EnsureRole(serviceProvider, managerID, Constants.ContactManagerRole);

                SeedDB(context, adminID);
            }
        }
        private static async Task<string> EnsureUser(IServiceProvider serviceProvider, string userPw, string UserName)
        {
            var userManager = serviceProvider.GetService<UserManager<IdentityUser>>();
            var user = await userManager.FindByNameAsync(UserName);

            if (user == null)
            {
                user = new IdentityUser
                {
                    UserName = UserName,
                    EmailConfirmed = true
                };
                await userManager.CreateAsync(user, userPw);
            }

            if (user == null)
            {
                throw new Exception("The password is probably not strong enough!");
            }

            return user.Id;

        }

        private static async Task<IdentityResult> EnsureRole(IServiceProvider serviceProvider, string uid, string role)
        {
            var roleManager = serviceProvider.GetService<RoleManager<IdentityRole>>();

            if (roleManager == null)
            {
                throw new Exception("roleManager null");
            }

            IdentityResult IR;
            if (!await roleManager.RoleExistsAsync(role))
            {
                IR = await roleManager.CreateAsync(new IdentityRole(role));
            }

            var userManager = serviceProvider.GetService<UserManager<IdentityUser>>();

            var user = await userManager.FindByIdAsync(uid);

            if (user == null)
            {
                throw new Exception("The User password was probably not strong enough!");
            }

            IR = await userManager.AddToRoleAsync(user, role);

            return IR;
        }

        public static void SeedDB(ApplicationDbContext context, string adminID)
        {
            
            if (context.Contact.Any())
            {
                return;   // DB has been seeded
            }

            context.Contact.AddRange(
                new Contact
                {
                    Name = "Frenal Gadani",
                    Address = "239, Hickling Trail",
                    City = "Barrie",
                    State = "On",
                    Zip = "L4W5M5",
                    Email = "frenalgadani@gmail.com",
                    Status = ContactStatus.Approved,
                    OwnerID = adminID
                },
                new Contact
                {
                    Name = "Nikhilesh Vashisht",
                    Address = "33B, College Crescent",
                    City = "Barrie",
                    State = "ON",
                    Zip = "L4M2W4",
                    Email = "nikhilesh.vashisht@yahoo.com",
                    Status = ContactStatus.Submitted,
                    OwnerID = adminID
                },
                 new Contact
                 {
                     Name = "Katherine Moulding",
                     Address = "18 York St Suite 400",
                     City = "Toronto",
                     State = "ON",
                     Zip = "M5J2T8",
                     Email = "kat.moulding@ymail.com",
                     Status = ContactStatus.Rejected,
                     OwnerID = adminID
                 },
                 new Contact
                 {
                     Name = "Garima Gulatti",
                     Address = "344, Hickling Trail",
                     City = "Barrie",
                     State = "ON",
                     Zip = "L4M45W5",
                     Email = "garimagulati146@gmail.com",
                     Status = ContactStatus.Submitted,
                     OwnerID = adminID
                 },
                 new Contact
                 {
                     Name = "Deidra Blackburn",
                     Address = "810 Blanshard St, Victoria",
                     City = "Redmond",
                     State = "BC",
                     Zip = "V8W2H2",
                     Email = "deidrablackburn1955@hotmail.com",
                     OwnerID = adminID
                 }
            );
            context.SaveChanges();
        }
    }
}
