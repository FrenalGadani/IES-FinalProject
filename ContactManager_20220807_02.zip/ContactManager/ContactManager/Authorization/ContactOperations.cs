﻿using Microsoft.AspNetCore.Authorization.Infrastructure;

namespace ContactManager.Authorization
{
    public class ContactOperations
    {
        public static OperationAuthorizationRequirement Create = new OperationAuthorizationRequirement { Name = Constants.CreateOpName };
        public static OperationAuthorizationRequirement Read = new OperationAuthorizationRequirement { Name = Constants.ReadOpName };
        public static OperationAuthorizationRequirement Update = new OperationAuthorizationRequirement { Name = Constants.UpdateOpName };
        public static OperationAuthorizationRequirement Delete = new OperationAuthorizationRequirement { Name = Constants.DeleteOpName };

        public static OperationAuthorizationRequirement Approve = new OperationAuthorizationRequirement { Name = Constants.ApproveOpName };
        public static OperationAuthorizationRequirement Reject = new OperationAuthorizationRequirement { Name = Constants.RejectOpName };
    }

    public class Constants
    {
        public static readonly string CreateOpName = "Create";
        public static readonly string ReadOpName = "Read";
        public static readonly string UpdateOpName = "Update";
        public static readonly string DeleteOpName = "Delete";

        public static readonly string ApproveOpName = "Approve";
        public static readonly string RejectOpName = "Reject";

        public static readonly string ContactAdminRole = "ContactAdmin";
        public static readonly string ContactManagerRole = "ContactManager";
    }
}
